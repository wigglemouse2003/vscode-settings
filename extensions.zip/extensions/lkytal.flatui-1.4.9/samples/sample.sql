
SELECT user_id FROM users WHERE user_id = 1